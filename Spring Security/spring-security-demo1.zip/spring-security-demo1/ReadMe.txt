Spring boot Security
---------------
1) Create s spring boot application using Spring initializer
      start.spring.io

2) Project name
       spring-security-demo

3)dependencies
    spring web
    spring security
    dev tools

4)Create a Rest Controller 
      MyController : / Hello world

    	 @RestController
	 public class MyController {
		@GetMapping("/")
		public String home() {
			return "Hello Kranthi - this is spring security demo";
	     }
          }

5) Run the application
     http://localhost:8080/

   what do you expect ?

   - Normally we get  o/p : Helli Kranthi

   - but, now we get Login page    (http://localhost:8080/Login)          l 
                   -username
                   -password 

     this is because we added spring-security dependency in pom.xm
    		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-security</artifactId>
		</dependency>

   - if you remove spring-security or commenting it in pom.xml now u will see  o/p Hello Kranthi
     of Rest Api

   *Why login has come whenever i access any url? This is becoz of "SecurityAutoConfiguration"

6) @SpringBootApplication(exclude = SecurityAutoConfiguration.class) (it is like disabling security dependency)
  
  - above annotation will exclude spring security login page & 
                      opens Rest controller service  - localhost:8080
  - create product & customer rest service methods also & try accessing it with urls
    http://localhost:8080/
    http://localhost:8080/product
    http://localhost:8080/customer

 Upto now we displayed only login page & but did not configured it

-----------Login Credentials---

 if username is "kranthi"
    password is "hitman"
  
    then login should be successfull
 
 - WebSecurityConfigurerAdaper
   	User
   	UserDetails
   	UserDetailsService
  
   These classes are already present in the security starter dependency.

7) Create (MyConfiguration.java) class:  
            extends WebSecurityConfigurerAdapter
             - overide unimplemented methods in adapter
                rightlcick -> source -> over unimplemented methods -> configure(AuthenticationManagerBuilder)
      
   - annotation @Configuration
   - @Autowire MyUserDetailsService in config  
    
 ------
       @Configuration
	public class MyConfiguration extends WebSecurityConfigurerAdapter{
  
		@Autowired
		private MyUserDetailsService userDetailsService;
	
		@Override
		protected void configure(AuthenticationManagerBuilder auth) throws Exception {
			//super.configure(auth);
		
			auth.userDetailsService(userDetailsService);
		}

		@Bean
		public PasswordEncoder passwordEncoder() {
		 
			return  NoOpPasswordEncoder.getInstance();
		}
	}
   ------

    -> if there is no PasswordEncoder it shows error : no PasswordEncoder mapped for id "null"

8) Create service class (MyUserDetailsService.java) :
                                 implements UserDetailsService
                            - add unimplemented methods & overide it

    - annotation @Service
    - load username & password 
  -------
	@Service
	public class MyUserDetailsService implements UserDetailsService {

		@Override
		public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
			// TODO Auto-generated method stub
			return new User("kranthi","hitman", new ArrayList<>());
		 
		}
	}
  --------
     
    -> here User is loaded by Username if Username is found it will send/load object of that user with
       username & password

9) Run application 
    login using  
            username : kranthi
            password : hitman
       
        -- successfully loged in  & then try accessing rest contreollers using above URLS
                  &
         if u give wrong details shows as Bad credentials