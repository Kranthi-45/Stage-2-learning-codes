package com.example.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {

	@GetMapping("/")
	public String home() {
		return "Hello Kranthi - this is spring security demo";
	}
	
	@GetMapping("/product")
	public String product() {
		return "welcome to product";
	}
	
	@GetMapping("/customer")
	public String customer() {
		return "welcome to customer";
	}
}
