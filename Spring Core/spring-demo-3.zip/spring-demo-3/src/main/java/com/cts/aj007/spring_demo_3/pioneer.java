package com.cts.aj007.spring_demo_3;

/* this pioneer class also implements audio interface so bean.xml cannot find perfect match because there are 2 implementations for audio type
 * and there are also two bean files found in bean.xml of pionner and sony
 *  and by default it will use autowire= byType, and get ambiguity beacause both are 1 type(audio), instead use byName to get output.
 */

/*
 * if you want to access specific type use byName auto wire and in car.java declare audio type also for specific type like sony or pionner.
 */
public class pioneer implements Audio{

	public void play() {
		System.out.println("pioneer audio playes music");
	}

}
