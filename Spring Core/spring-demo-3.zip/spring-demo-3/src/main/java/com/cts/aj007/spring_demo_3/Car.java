package com.cts.aj007.spring_demo_3;

public class Car {
	private String name;
	private String brand;
	//private Sony Sony;
// used & declare Sony variable as sony or pioneer to specific type, & to demontrate autowire="byName". 
	private Audio Sony;

	public Car() {}
	public Car(String name, String brand, Audio Sony) {
		super();
		this.name = name;
		this.brand = brand;
		this.Sony = Sony;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public Audio getSony() {
		return Sony;
	}
	public void setSony(Audio Sony) {
		this.Sony = Sony;
	}
	@Override
	public String toString() {
		return "Car [name=" + name + ", brand=" + brand + ", Sony=" + Sony + "]";
	}


}
