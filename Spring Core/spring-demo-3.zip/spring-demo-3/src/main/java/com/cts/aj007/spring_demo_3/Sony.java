package com.cts.aj007.spring_demo_3;

public class Sony implements Audio{

	public void play() {
		System.out.println("Sony audio playes music");
	}
}
