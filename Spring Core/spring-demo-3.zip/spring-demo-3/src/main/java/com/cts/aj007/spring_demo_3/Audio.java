package com.cts.aj007.spring_demo_3;

public interface Audio {
 abstract void play();
}
