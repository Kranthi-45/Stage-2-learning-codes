
	import java.util.*;
	public class powerprogress {
			    public static void main(String[] args) {
			        Scanner sc = new Scanner(System.in);
			        int base = sc.nextInt();
			        int exponent = sc.nextInt();
			        if(base<=0){
			            System.out.println(base+" is an invalid");
			            System.exit(0);
			            
			        }
			        if(exponent<=0){
			            System.out.println(exponent+" is an invalid");
			            System.exit(0);
			            
			        }
			        if(base>exponent){
			            System.out.print(base+" is not less than "+exponent);
			            System.exit(0);
			            
			        }
			        for(int i=1;i<=exponent;i++){
			            System.out.print( (int) Math.pow(base,i)+ " ");
			            
			        }
			        
			    }
			    
	}



