package com.cts.aj007.spring_demo_2;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import com.cts.aj007.spring_demo_2.entity.Employee;

import com.cts.aj007.spring_demo_2.entity.Department;   // imported this only for last demo for list
import java.util.List;   // imported only for last demo using list
/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
//    ### we do not create employee obj. we will get instance from Spring IOC 
//    ### for that we have to define bean.xml   
        
//        Employee employee = new Employee();  --------------Employee [employeeId=null, firstName=null, lastName=null]
//        System.out.println(employee);     #######will gives output null for all attributes in employee obj because no obj instance created
  
        
//       ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
//       Employee emp=(Employee) ctx.getBean("emp");       
//        System.out.println(emp);      -------------------- Employee [employeeId=E100, firstName=Rama, lastName=Krishna]
       
   
//        ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
//        Employee emp1=(Employee) ctx.getBean("emp1");       
//        Employee emp2=(Employee) ctx.getBean("emp2");       
//         System.out.println(emp1);       --------------------Employee [employeeId=E101, firstName=Kranthi, lastName=Kumar]
//         System.out.println(emp2);      ---------------------Employee [employeeId=E102, firstName=Rohit, lastName=Sharma]
//         
//        emp1.setFirstName("Sravu"); 
//        System.out.println(emp1);       ----------------------Employee [employeeId=E101, firstName=Sravu, lastName=Kumar]
//
//        String empId = emp2.getEmployeeId();
//        System.out.println(empId);       ---------------------E102

        
//       ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
//       Employee x=(Employee) ctx.getBean("emp1");       
//       Employee y=(Employee) ctx.getBean("emp1");   
//       Employee z=(Employee) ctx.getBean("emp1");   
//       x.setFirstName("X");
//       y.setFirstName("Y");
//       z.setFirstName("Z");
//       System.out.println(x.getFirstName());     
//       System.out.println(y.getFirstName());      
//       System.out.println(z.getFirstName());      
//
//  -----<bean name="emp" class="com.cts.aj007.spring_demo_2.entity.Employee" scope="singleton"> use singleton scope for getting a single z value
//-----<bean " " scope="prototype"> use prototype scope for getting all different set values for the same emp obj like o/p : x, y, z
        
     
        
        
//      ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
//      Employee emp1=(Employee) ctx.getBean("emp1");       
//       System.out.println(emp1);      
//
//     ### used two diff classes of employee and adress and we have used address class instance as reference in employee 
//     ### for this we need to add extra bean with address and use ref keyword in employee to use address class instance.
//        
// ----Employee [employeeId=E101, firstName=Kranthi, lastName=Kumar, address=Address [doorNo=A123, street=Nehrunagar, city=Sircilla, pincode=505301]]

        
        ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
       Department d=(Department) ctx.getBean("department");       
       System.out.println(d.getDepartmentId());       
       System.out.println(d.getDepartmentName());        
       List<Employee> employees  = d.getEmployees();
       for(Employee e :employees) {
           System.out.println(e);        
       }
        
        
    }
}
