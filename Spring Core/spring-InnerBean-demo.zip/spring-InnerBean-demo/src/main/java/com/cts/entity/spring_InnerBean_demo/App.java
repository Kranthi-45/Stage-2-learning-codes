package com.cts.entity.spring_InnerBean_demo;

/**
 * Hello world!
 *
 */
//public class App 
//{
//    public static void main( String[] args )
//    {
//        System.out.println( "Hello World!" );
//    }
//}
//package com.spring.ui;
//import com.spring.app.Address;
//import com.spring.app.AddressBook;
import com.cts.entity.spring_InnerBean_demo.Address;
import com.cts.entity.spring_InnerBean_demo.AddressBook;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.util.Scanner;

public class App {
	
	
	public static AddressBook loadAddressBook()
	{
        ApplicationContext ctx = new ClassPathXmlApplicationContext("src/main/java/applicationContext.xml");
        AddressBook addBook=(AddressBook) ctx.getBean("AddressBook");
		return addBook;
	}
	
	public static void main(String[] args)
	{
		//invoke the loadAddressBook() method from main retrieve the AddressBook object, get the details from the user set the values and display the values
           Scanner scanner = new Scanner(System.in);
           AddressBook addressBook =  loadAddressBook(); 
             
        System.out.println("Enter the temporary address");
        System.out.println("Enter the house name");
        String houseName = scanner.nextLine();
        System.out.println("Enter the street");
        String street = scanner.nextLine();
        System.out.println("Enter the city");
        String city = scanner.nextLine();
        System.out.println("Enter the state");
        String state = scanner.nextLine();
        System.out.println("Enter the phone number");
        String phoneNumber = scanner.nextLine();

        addressBook.getTempAddress().setHouseName(houseName);
        addressBook.getTempAddress().setStreet(street);
        addressBook.getTempAddress().setCity(city);
        addressBook.getTempAddress().setState(state);
        addressBook.setPhoneNumber(phoneNumber);
           
          
            System.out.println("Temporary address");
            System.out.println("House name:"+addressBook.getTempAddress().getHouseName());
            System.out.println("Street:"+addressBook.getTempAddress().getStreet());
            System.out.println("City:"+addressBook.getTempAddress().getCity());
            System.out.println("State:"+addressBook.getTempAddress().getState());
            System.out.println("Phone number :"+addressBook.getPhoneNumber());
	}

}
