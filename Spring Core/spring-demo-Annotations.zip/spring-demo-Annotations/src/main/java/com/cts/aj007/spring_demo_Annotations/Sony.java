package com.cts.aj007.spring_demo_Annotations;

import org.springframework.stereotype.Component;

// below component annotation used instead xml configuration
@Component("sony")
public class Sony implements Audio{
    
	public void play() {
		System.out.println("Sony audio playes music");
	}
}
