package com.cts.aj007.spring_demo_Annotations;

public interface Audio {
public void play();
}
