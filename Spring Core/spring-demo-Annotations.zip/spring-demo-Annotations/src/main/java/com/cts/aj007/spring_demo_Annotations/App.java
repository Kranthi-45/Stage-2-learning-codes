package com.cts.aj007.spring_demo_Annotations;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        //not useing classpathxml application
        AnnotationConfigApplicationContext ctx =new  AnnotationConfigApplicationContext();
        // we have not created a config class in this project
        ctx.scan("com.cts");
        ctx.refresh();
        Car car = ctx.getBean(Car.class);
        car.getSony().play();
    }
}
