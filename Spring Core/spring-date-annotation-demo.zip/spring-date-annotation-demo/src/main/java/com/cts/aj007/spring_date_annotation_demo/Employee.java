package com.cts.aj007.spring_date_annotation_demo;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

/* for annotations it will show red color until we import packages and those packages will visible only 
 * when in pom.xml has both core & context dependencies was declared
 */
@Component
public class Employee {
	private int employeeId;
	private String firstName;
	private String lastName;
	
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date dateOfJoining;
	public Employee() {}

	public Employee(int employeeId, String firstName, String lastName, Date dateOfJoining) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfJoining = dateOfJoining;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", dateOfJoining=" + dateOfJoining + "]";
	}
	
}
