package com.cts.aj007.spring_demo_AnnotationConfigClass;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        AnnotationConfigApplicationContext ctx =new  AnnotationConfigApplicationContext(AppConfig.class);
        // Using Appconfig class in this project ----- no need to use scan and refresh because we have passed appconfig diretly no need to scan all folders
     
//        ctx.scan("com.cts");
//        ctx.refresh();
        Car car = ctx.getBean(Car.class);
        car.getSony().play();
    }
}
