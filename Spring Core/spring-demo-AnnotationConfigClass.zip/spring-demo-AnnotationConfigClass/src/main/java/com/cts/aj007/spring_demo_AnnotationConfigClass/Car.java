package com.cts.aj007.spring_demo_AnnotationConfigClass;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Car {
	private String name;
	private String brand;
	
	@Autowired
	private Audio sony;

	public Car() {}
	public Car(String name, String brand, Audio sony) {
		super();
		this.name = name;
		this.brand = brand;
		this.sony = sony;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public Audio getSony() {
		return sony;
	}
	public void setSony(Audio sony) {
		this.sony = sony;
	}
	@Override
	public String toString() {
		return "Car [name=" + name + ", brand=" + brand + ", sony=" + sony + "]";
	}


}
