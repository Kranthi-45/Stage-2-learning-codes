package com.cts.aj007.spring_demo_AnnotationConfigClass;

public interface Audio {
public void play();
}
