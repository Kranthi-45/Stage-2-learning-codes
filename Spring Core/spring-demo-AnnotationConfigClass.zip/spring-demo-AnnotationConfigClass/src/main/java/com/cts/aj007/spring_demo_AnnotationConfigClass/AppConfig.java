package com.cts.aj007.spring_demo_AnnotationConfigClass;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.ComponentScan;

// here only using scan directly and passing this class as parameter 

@Configurable
@ComponentScan("com.cts")
public class AppConfig {

}
