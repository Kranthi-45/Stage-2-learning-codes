package com.cts.test;

import org.junit.experimental.categories.Categories;
import org.junit.experimental.categories.Categories.IncludeCategory;
import org.junit.runner.RunWith;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Categories.class)   

//@IncludeCategory(Even.class)
@IncludeCategory({Odd.class,Even.class})

//@SuiteClasses(ArithTest.class)
@SuiteClasses({ArithTest.class,MathsTestSetUpTearDown.class})

public class MyTestSuite_Include {

}

/*@IncludeCategory includes the test methods categories of particular Suite class all test methods or only some methods in suite class 
 * ------ if we declare @Category as class level in test.java to come under all test methods to that Includecategory(interface)
 * -------if we declare @category as method level in test.java to select particular method belongs to  Includecategory(interface)
 * 
 *@SuiteClasses for which which test classes should be included and tested
 *@IncludeCategory will test only that classes which are mentioned in the suite classes. 
 * 
 */
