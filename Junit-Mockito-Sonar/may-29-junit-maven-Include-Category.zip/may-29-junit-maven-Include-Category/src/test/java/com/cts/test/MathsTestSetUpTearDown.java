package com.cts.test;
import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.rules.ExpectedException;

import com.cts.junit.Maths;

@Category({Even.class,Odd.class})                // used @category at the class level
public class MathsTestSetUpTearDown {

	private Maths aut= new Maths();
	
	@BeforeClass
	public static void onceSetup() {
		System.out.println("The before class setup is done");
	}

	@Before
	public void setup() {
		System.out.println("Before is executed now");
		aut.setNo1(2.0);
		aut.setNo2(1.0);
	}

	@Test
	public void test1() {	
		aut.sum();
		assertEquals(new Double(3.0), aut.getResult());
	}
	@Test
	public void testDifference() {
		aut.difference();
		assertEquals(new Double(1.0), aut.getResult());
	}
	
	@Test
	@Ignore                   // Ignore means if the result will fail it will ignore this test case and not effect on overall result
	public void testProduct() {
		aut.product();
		assertEquals(new Double(39.0), aut.getResult());
	}
	
	@After
	public void tearDown() {
		aut=null;
	}
	
	//------------------------------------------------------------------------------------
	/* Demonstration of @Rule - exception  */
	
	@Rule
	public ExpectedException exc = ExpectedException.none();
	
	@Test
	public void testDivide() {
		aut.setNo1(10.0);
		aut.setNo2(0.0);
	    int i=20;
	    int j=0;                                 // it will result green because j=0 if exception occurs and remaining statments not executed afte exc
		exc.expect(ArithmeticException.class);
		System.out.println(i/j);
		
		System.out.println(aut.divide1(i, j));   // another divide() declared in maths.java file
		aut.divide();
		Double res = aut.getResult();
		System.out.println(res);
	}
//--------------------------------------another way of declaring exception rule------------------------
	
//	@Test(expected = ArithmeticException.class)
//	public void testDivid() {
//		aut.setNo1(10.0);
//		aut.setNo2(0.0);
//	    int i=20;
//	    int j=0; 
//	    
//		System.out.println(aut.divide1(i, j));  
//		aut.divide();
//		Double res = aut.getResult();
//		System.out.println(res);
//	}
}
