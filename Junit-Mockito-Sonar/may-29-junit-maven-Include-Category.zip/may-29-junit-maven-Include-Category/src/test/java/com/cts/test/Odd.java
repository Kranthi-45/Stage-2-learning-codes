package com.cts.test;

public interface Odd {

}
