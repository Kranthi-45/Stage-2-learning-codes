package com.cts.test;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import com.cts.junit.Maths;

/* @Parameterized.class used in (test.java class) to test java classes (ex: Maths.java)
 * suppose if we want to test Sum() method of Maths.java class with more number of given inputs/test cases use "Parameterized for testing"
 * -with multiple values.
 */

@RunWith(Parameterized.class)
public class MathsParamTest {

	Double no1,no2,expectedResult;
	Maths aut = new Maths();
	public MathsParamTest(Double no1, Double no2, Double expectedResult) {
		super();
		this.no1 = no1;
		this.no2 = no2;
		this.expectedResult = expectedResult;
	}
	
	@Parameterized.Parameters
	public static Collection inputs()
	{
		return Arrays.asList( new Object[][] {
			{2.0,3.0,5.0},
			{4.0,5.0,9.0},
			{11.0,12.0,23.0}
		});
	}
	
	@Test
	public void testSum() {
		aut.setNo1(no1);
		aut.setNo2(no2);
		aut.sum();
		assertEquals(new Double(expectedResult),aut.getResult());
	}
}





