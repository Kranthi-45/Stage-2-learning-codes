package com.cts.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.experimental.categories.Category;

public class ArithTest {

	
	@Test
	public void test1() {
		assertTrue(false);
	}
	
	@Category(Even.class)
	@Test
	public void test2() {
		assertFalse(false);
	}
	
	@Category({Even.class,Odd.class})
	@Test
	public void test3() {
		assertEquals(3,3);
	}

}
// in this we used @category at method level for individual method