package com.cts.test;

public interface Even {

}
