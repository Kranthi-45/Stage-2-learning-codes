package com.cts.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.cts.junit.Maths;

// while creating maven project for unit testing copy j-unit maven dependency in pom.xml
public class MathsTest {

	private Maths aut= new Maths();
	
	@Test
	public void test1Sum() {
	//	assertEquals(1,1);                        // testing snippet evaluates true becoz o/p are same
	//  assertEquals(1,10);                       // testing snippet evaluates false becoz outputs are diff
    //  assertEquals(120.0, aut.getResult());     // error shows ambiguous obj,obj so use obj type instead reference type as below.
	
		aut.setNo1(100.0);
		aut.setNo2(20.0);
		aut.sum();
	    assertEquals(new Double(120.0), aut.getResult());
	}
	
	@Test
	public void test2Difference() {
			aut.setNo1(100.0);
			aut.setNo2(20.0);
			aut.difference();
		   assertEquals(new Double(-1.0), aut.getResult());
		}
}
// Evaluates OVERALL Program to true(Green) only when above two or all @Test methods are true, if one test method fails whole output will be failed(Red).

/* Instead of declaring or supplying separate inputs for each @Test method,instead use method setup() and teardown() to overcome that
 *  -give sample inputs in one method (in setup()) use it for all test methods,
 *  -for that creating new separate java class.
 * 
 */