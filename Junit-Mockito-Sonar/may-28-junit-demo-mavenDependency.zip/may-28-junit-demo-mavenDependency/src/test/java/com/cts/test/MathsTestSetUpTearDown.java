package com.cts.test;
import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.cts.junit.Maths;

public class MathsTestSetUpTearDown {

	private Maths aut= new Maths();
	/* @Before is used for setting one set of input variables in 1 separate method to test all methods       ---> Pre condition.
	 * @After is use for closing connections to free the resources                                           ---> Post condition.
	 * @Before is called N number of times for N number of @Test methods (ex: 2 times for 2 test_methods)    ---> executed for each method.
	 * @BeforeClass is should be declared as  static method         --------------------------------------------> executed once per class.
	 * 
	 * Irrespective of all the test methods are passed or not..the print statements in "@Before" setup() will print for every method.
	 */
	@BeforeClass
	public static void onceSetup() {
		System.out.println("The before class setup is done");
	}

	@Before
	public void setup() {
		System.out.println("Beforeing is executed now");
		aut.setNo1(2.0);
		aut.setNo2(1.0);
	}

	@Test
	public void test1() {	
		aut.sum();
		assertEquals(new Double(3.0), aut.getResult());
	}
	@Test
	public void testDifference() {
		aut.difference();
		assertEquals(new Double(1.0), aut.getResult());
	}
	
	@Test
	@Ignore                   // Ignore means if the result will fail it will ignore this test case and not effect on overall result.
	public void testProduct() {
		aut.product();
		assertEquals(new Double(39.0), aut.getResult());
	}
	
	@After
	public void tearDown() {
		aut=null;
	}
	
//-------------------------------------------------------Exception Throwing method1------------------------------------------------------------------------
	
   /* Demonstration of @Rule - exception  & we are again initializing the i/p becoz we are written this method after teardown(),where connection closed.
   */
	
	@Rule
	public ExpectedException exc = ExpectedException.none();
	
	@Test
	public void testDivide() {
		aut.setNo1(10.0);
		aut.setNo2(0.0);
	    int i=20;
	    int j=0;                               // it will result green because j=0 Arith exception occurred and remaining statements not executed after exc.
		exc.expect(ArithmeticException.class);
		System.out.println(i/j);
		
		System.out.println(aut.divide1(i, j));  // another divide() declared in maths.java file
		aut.divide();
		Double res = aut.getResult();
		System.out.println(res);
	}
	
//-------------------------------------------------------Exception Throwing method 2------------------------------------------------------------------------
	
//	@Test(expected = ArithmeticException.class)
//	public void testDivid() {
//		aut.setNo1(10.0);
//		aut.setNo2(0.0);
//	    int i=20;
//	    int j=0; 
//	    
//		System.out.println(aut.divide1(i, j));  
//		aut.divide();
//		Double res = aut.getResult();
//		System.out.println(res);
//	}
}
