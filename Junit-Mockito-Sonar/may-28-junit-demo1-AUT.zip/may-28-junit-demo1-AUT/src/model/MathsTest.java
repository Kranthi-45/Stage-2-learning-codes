package model;

import static org.junit.Assert.assertEquals;

import junit.framework.TestCase;

public class MathsTest extends TestCase{            // use "extends TestCase" when we don't use "@Test" annotation 
	Maths aut = new Maths();	
	public void testsum() {
		aut.setNo1(100.0);
		aut.setNo2(20.0);
		aut.sum();
	//	assertEquals(new Double(120.0), aut.getResult());
		assertEquals(120.0, aut.getResult());
	// if you want detail printing of test case in console create new main class use "JUnitCore.runclasses()" method.
}
	
	public void testproduct() {
		aut.setNo1(100.0);
		aut.setNo2(20.0);
		aut.product();
		assertEquals(2001.0, aut.getResult());
}
 //-----------------------------------------------------------------------------------------------------------------
	//	public void testsum() {               // for individual checking
	//	
	//		assertEquals(10.0,10.0);          // it results green becoz (actual o/p, expected op) = (10,10)is same
	//     assertEquals(110.0,10.0);          // it results fail red becoz (actual o/p, expected op) is different
	//
	//	}

}
