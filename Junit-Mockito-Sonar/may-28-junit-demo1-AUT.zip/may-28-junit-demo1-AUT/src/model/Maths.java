package model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class Maths {
	private Double no1;
	private Double no2;
	private Double result;

	public Maths() {}
	public Maths(Double no1, Double no2, Double result) {
		super();
		this.no1 = no1;
		this.no2 = no2;
		this.result = result;
	}
	public Double getNo1() {
		return no1;
	}
	public void setNo1(Double no1) {
		this.no1 = no1;
	}
	public Double getNo2() {
		return no2;
	}
	public void setNo2(Double no2) {
		this.no2 = no2;
	}
	public Double getResult() {
		return result;
	}
	public void setResult(Double result) {
		this.result = result;
	}

	public void sum() {
		result= no1+no2;
	}
	public void difference() {
		result= Math.abs(no1+no2);;
	}
	public void product() {
		result=  no1*no2;
	}
	public void divide() {
		result= no1/no2;
	}
     
//dont create both code and test logic in the same program as below, create in another new class	
	
//	@Test
//	public void testsum() {
//		no1=10.0;
//		no2=5.0;
//		assertEquals(new Double(15.0),result);
//	}


}
