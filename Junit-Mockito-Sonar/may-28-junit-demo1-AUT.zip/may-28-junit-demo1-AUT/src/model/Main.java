package model;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Result results =  JUnitCore.runClasses(MathsTest.class);
       System.out.println(results.getFailureCount());
       for(Failure f: results.getFailures()) {
    	   System.out.println(f);
     // output will be  0 becoz no failures occurs there is nothing to print failures and failure count is zero 0;
     // if you give inputs in testclass which will get failed then output will be displayed with count and why it is failed message;
     // run using as java application to print error message becoz we are displaying error in java main class not in test unit class;	
     // Add "(junit-4.10.jar)" for junit testing if it is not maven project.
        }
	}
}
// if there are errors in 2 methods(like sum(),dif(),prod()...) it displays all count errors of each @Test method along with message