package com.cts.test;
import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.cts.junit.Maths;

public class MathsTestSetUpTearDown {

	private Maths aut= new Maths();
	/* @Before is used for setting one set of input varibles in 1 seperate method to test all methods ---- Pre condition
	 * @After is use for closing connections to free the resources                                    ---- Post condition
	 * @Before is called N number of times  for N numer of methods (ex: 2 times for 2 methods)        ---- executed for each method
	 * @BeforeClass is used      static method  ----------------------------------------------------------executed once per class
	 * 
	 * Irrespective of all the test methods are passed or not.. the print statements in setup will print for everymethod.
	 */
	@BeforeClass
	public static void onceSetup() {
		System.out.println("The before class setup is done");
	}

	@Before
	public void setup() {
		System.out.println("Before is executed now");
		aut.setNo1(2.0);
		aut.setNo2(1.0);
	}

	@Test
	public void test1() {	
		aut.sum();
		assertEquals(new Double(3.0), aut.getResult());
	}
	@Test
	public void testDifference() {
		aut.difference();
		assertEquals(new Double(1.0), aut.getResult());
	}
	
	@Test
	@Ignore                   // Ignore means if the result will fail it will ignore this test case and not effect on overall result
	public void testProduct() {
		aut.product();
		assertEquals(new Double(39.0), aut.getResult());
	}
	
	public void tearDown() {
		aut=null;
	}
	
	//------------------------------------------------------------------------------------
	/* Demonstration of @Rule - exception  & we are again intializing the i/p becoz we are written this method after 
	 * teardown() where connecion closed.
	 */
	@Rule
	public ExpectedException exc = ExpectedException.none();
	
	@Test
	public void testDivide() {
		aut.setNo1(10.0);
		aut.setNo2(0.0);
	    int i=20;
	    int j=0;                // it will result green because j=0 if exception occurs and remaining statments not executed afte exc
		exc.expect(ArithmeticException.class);
		System.out.println(i/j);
		
		System.out.println(aut.divide1(i, j));  // another divide() declared in maths.java file
		aut.divide();
		Double res = aut.getResult();
		System.out.println(res);
	}
//--------------------------------------another way of declaring exception rule------------------------
	
//	@Test(expected = ArithmeticException.class)
//	public void testDivid() {
//		aut.setNo1(10.0);
//		aut.setNo2(0.0);
//	    int i=20;
//	    int j=0; 
//	    
//		System.out.println(aut.divide1(i, j));  
//		aut.divide();
//		Double res = aut.getResult();
//		System.out.println(res);
//	}
}
