package com.cts.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ArithTest {

	@Test
	public void test1() {
		assertTrue(false);
	}
	@Test
	public void test2() {
		assertFalse(false);
	}
	@Test
	public void test3() {
		assertEquals(1,3);
	}

}

/// if above all test cases passed so "Green" color appears...if one test case that leads to fail whole o/p will fails( "Red" color).