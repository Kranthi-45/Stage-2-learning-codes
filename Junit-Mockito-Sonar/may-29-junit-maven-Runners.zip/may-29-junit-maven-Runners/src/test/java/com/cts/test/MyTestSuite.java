package com.cts.test;

import org.junit.experimental.categories.Categories;
import org.junit.experimental.categories.Categories.IncludeCategory;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
//@SuiteClasses(ArithTest.class)             // ----------------- only one class included same as below where 2 classes included
@SuiteClasses({ArithTest.class, MathsTestSetUpTearDown.class})

public class MyTestSuite {

}


