
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int i = 40;
      int j = 5;
      System.out.println(i+j);
	}

}
