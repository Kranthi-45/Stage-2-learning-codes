
public class Example {
   Maths maths;
   
   // we inject maths interface using setter based or constructor based injection.
   // use constructor injection for injecting maths interface for implementation of sum().
   public Example(Maths maths) {
	super();
	this.maths = maths;
}
public int compute(int x, int y) {
	   int result = maths.sum(x, y);
	   return result;
   }
}
