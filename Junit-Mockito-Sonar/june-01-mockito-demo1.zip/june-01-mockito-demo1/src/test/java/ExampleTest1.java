import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Test;

public class ExampleTest1 {

	
	@Test
	public void testSum2() {
		Maths maths  = mock(Maths.class);	
		when(maths.sum(3,3)).thenReturn(6);  
		when(maths.sum(2,3)).thenReturn(5); 
		
		Example ex = new Example(maths);   
		int result=ex.compute(3,3);         //------ test_1 condition for 1_mock method
		System.out.println(result);          
		assertEquals(6,result);
		
		result=ex.compute(2,3);        
		System.out.println(result);         //----------test_2 condition for 2_mock method
		assertEquals(5,result);
		
	}
}
/* we have used two mock test conditions in above code [2 when()...] so we have to test the above any of two mocks by giving inputs
 * to test conditions for 1 mock method or 2 methods.
 * ----------------------------------------or-----------------------------------------
 * we can write two separate compute() test conditions in 1 testSum2() for two different mocks separately in
 * 
 * ------------------------------------------or---------------------------------------
 * if we want to write two separate test cases in two different test methods [i,e..testSum1() & testSum2()] for two separate mocks
 * see next code ExampleTest3.java
 */
