import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.BeforeClass;
import org.junit.Test;

/* setUp() is used for common configurations methods which are common steps for all testCase methods are declared in this,
 * and also for each more testcase method u add & check along with that also add when().thenReturn() method in setup() method. 
 * 
 */
public class ExampleTest3 {   
	static Maths maths;
	static Example ex;
	
	@BeforeClass
	public static void setUp() {
		maths  = mock(Maths.class);	
	    ex = new Example(maths);  
		when(maths.sum(3,3)).thenReturn(6);  
		when(maths.sum(2,3)).thenReturn(5); 
		when(maths.sum(13,13)).thenReturn(26); 

	}
	
	@Test
	public void testSum1() {  
		int result=ex.compute(3,3);         //------ test_1 condition for 1_mock method
		System.out.println(result);          
		assertEquals(6,result);	
	}
	@Test
	public void testSum2() { 
		int result=ex.compute(2,3);         //------ test_1 condition for 1_mock method
		System.out.println(result);          
		assertEquals(5,result);	
	}
	@Test
	public void testSum3() { 
		int result=ex.compute(13,13);         //------ test_1 condition for 1_mock method
		System.out.println(result);          
		assertEquals(26,result);	
	}
}
