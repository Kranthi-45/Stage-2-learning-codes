import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Test;

public class ExampleTest {
//
//	@Test
//	public void testSum1() {
//		Maths maths  = mock(Maths.class);	
//		when(maths.sum(2,3)).thenReturn(5);     // mocking obj result 
//		
//		Example ex = new Example();
//		int result=ex.compute(2,3);  //  normal actual calling method result
//		System.out.println(result);
//		
//		assertEquals(5,result);
//	}
//	
	/* the above test mocking method result failed as null pointer exception becoz 
	 * while instantiating example not passed interface as constructor injection ... so it is empty results null
	 */
	
	
	@Test
	public void testSum2() {
		Maths maths  = mock(Maths.class);	
		when(maths.sum(3,3)).thenReturn(5);  // mocking obj result -- we have to just return own result by expecting  accorfing to inputs
		
		Example ex = new Example(maths);    // pass maths interface in the constructor to avoid null pointer exception
		int result=ex.compute(2,3);         //  normal actual calling method result
		System.out.println(result);
		
	//	assertEquals(expected,actual); 
		assertEquals(5,result);             // expected 5 we have to write & actual is gennerated by mockito
	}
	
	
}
