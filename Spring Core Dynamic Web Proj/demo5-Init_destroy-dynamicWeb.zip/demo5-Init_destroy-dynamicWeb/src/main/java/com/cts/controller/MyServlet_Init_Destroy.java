package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlet_Init_Destroy
 */
@WebServlet("/MyServlet_Init_Destroy")
public class MyServlet_Init_Destroy extends HttpServlet {
	
	int i = 45;  //-------------------------------written line
	
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyServlet_Init_Destroy() {
        super();
        // TODO Auto-generated constructor stub
    }

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		System.out.println("This is a destroy method.......");
		super.destroy();
	}

	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		System.out.println("........This is a init method");
		super.init();
	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println(i);
        System.out.println(".....The service method now.....");
		PrintWriter out = response.getWriter();
		int no3 = Integer.parseInt(request.getParameter("no1"));
		int no4 = Integer.parseInt(request.getParameter("no2"));
	    i = no3;
		out.println("Sum of real int values "+no3+" and "+no4+ " : " + no3+no4);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		//---------------- below method executes when in html <form tag> attribute  method="POST" is declared.
		response.getWriter().print("This is POST method");
		doGet(request, response);
	}

}
