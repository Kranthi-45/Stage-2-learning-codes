package com.cts.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
//import java.util.ResourceBundle;
import java.util.ResourceBundle;

import com.cts.model.Branch;


/* step1 : model class = Branch.java --> BranchDao.java
 * step2 : Branch.html file
 * step3 : Controller  = BranchServlet.java & see wheather the apache tomcat v.90 is added or not (add tomcat.jar or tomcat dependency).
 * step4 : After all steps while running program from branh.html if you get error as
 *       error: (HTTP 404 The origin server did not find a current representation for the target resource) try closing browser or ide 
 *              restart server
 */

/* first copy "mysql-connector-bin.jar" file to lib folder becoz we need to store data into mysql server 
*  or retrieve data from server or database.
*  
*  to know weather mysql.jar is copied and configured correctly or not 
*  (right click proj-> properties-> Deployment Assembly (if you won't find mysql-connector.jar row with in  WEB-INF/lib then add externally there))
*  
*  After this next create "branch.html" file &  copy some code snippet from bootstrap(W3schools bootstrap) 
*  program into html file.
*/
public class BranchDao {
	
 // private Connection getConnection() throws ClassNotFoundException, SQLException {
	//  Class.forName("com.mysql.jdbc.Driver");                                                          // ----------METHOD_1 - Direct Connection
	//  return DriverManager.getConnection("jdbc:mysql://localhost:3306/kranthis","root","Ks_961796");  
	
	/*instead of creating connection directly here create separate file with db.properties
	 * (right click src/main->New->other->search "file"-> name-db.properties) and use "ResourceBundle" in "Dao" as below
	 * 
	 */
	//}
  private Connection getConnection() throws ClassNotFoundException, SQLException
	{
	  ResourceBundle rb = ResourceBundle.getBundle("db");                                            // ----------METHOD_2- Using ResourceBundle(db)
	  Class.forName(rb.getString("driver"));
	  return DriverManager.getConnection(rb.getString("url"),rb.getString("username"),rb.getString("password"));
	}
  
	public int create(Branch branch) throws ClassNotFoundException, SQLException {
		//insert
		Connection con = getConnection();
		PreparedStatement st = con.prepareStatement("INSERT INTO branch VALUES(?,?,?)");
		st.setString(1, branch.getBid());
		st.setString(2, branch.getBname());
		st.setString(3, branch.getBcity());
		int no = st.executeUpdate();
		con.close();
		return no;
	}
  
	public List<Branch> read() throws ClassNotFoundException, SQLException {
		//select all
		Connection con = getConnection();
		PreparedStatement st = con.prepareStatement("SELECT * FROM branch");
		ResultSet rs = st.executeQuery();
		// rs as records each record is stored in Branch object . All object in a List<Branch>
		List<Branch> branchList = new ArrayList<>();
		while(rs.next()) {
			Branch branch =  new Branch(rs.getString(1),rs.getString(2),rs.getString(3));
			branchList.add(branch);
		}
		con.close();
		return branchList;
	}

	public Branch read(String bid) throws ClassNotFoundException, SQLException {
		//select by bid
		Connection con = getConnection();
		PreparedStatement st = con.prepareStatement("SELECT * FROM branch WHERE bid = ?");
		st.setString(1, bid);
		ResultSet rs = st.executeQuery();
		
		Branch branch = null;
		while(rs.next()) {
			branch = new Branch(rs.getString(1),rs.getString(2),rs.getString(3));
		}
		con.close();
		return branch;
	}

	public int update(Branch branch) throws ClassNotFoundException, SQLException {
		//update
		Connection con = getConnection();
		PreparedStatement st = con.prepareStatement("UPDATE Branch SET bname=?, bcity=? WHERE bid=?");
		st.setString(1, branch.getBname());
		st.setString(2, branch.getBcity());
		st.setString(3, branch.getBid());
		int no=st.executeUpdate();
		con.close();
		return no;
		
	}

	public int delete(String bid) throws ClassNotFoundException, SQLException {
		//delete
		Connection con =  getConnection();
		PreparedStatement st = con.prepareStatement("DELETE FROM branch WHERE bid=?");
		st.setString(1,bid);
		int no = st.executeUpdate();
		con.close();
		return no;
	}

}
