package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.dao.BranchDao;
import com.cts.model.Branch;

/**
 * Servlet implementation class BranchServlet
 */
@WebServlet("/BranchServlet")
public class BranchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BranchServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String btn = request.getParameter("btn");
		String bid,bname,bcity;
		bid = request.getParameter("bid");
		
		BranchDao bdao = new BranchDao();
		Branch branch =  null;
		int no = 0;
		PrintWriter out = response.getWriter();
		
		switch(btn)
		{
		case "Add":
			bname = request.getParameter("bname");
			bcity = request.getParameter("bcity");
			
			branch = new Branch(bid,bname,bcity);
			try {
				no = bdao.create(branch);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			out.print(no + " row(s) inserted");
		    break;
		    
		case "Modify":
			bname = request.getParameter("bname");
			bcity = request.getParameter("bcity");
			
			branch = new Branch(bid,bname,bcity);
			try {
				no = bdao.update(branch);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			out.print(no + " row(s) updated or affected");
		    break;
		    
		case "Delete":
			bid = request.getParameter("bid");
			try {
				no = bdao.delete(bid);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			out.print(no+" row(s) deleted");
			break;
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
