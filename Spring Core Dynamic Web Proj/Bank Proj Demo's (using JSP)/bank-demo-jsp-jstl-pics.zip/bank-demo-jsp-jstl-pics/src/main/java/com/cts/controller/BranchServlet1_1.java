package com.cts.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.cts.dao.BranchDao;
import com.cts.model.Branch;

/**
 * Servlet implementation class BranchServlet
 */

/* below URL mapping of servlet & href <a> hyperlink in (index_redirecting.jsp file) mapping should be same to redirect to this page ,perform operations & produce o/p
*  Add @Multipart annotation in servlet and write the code in doPOST() method instead doGet() for the picture element...
*   
*   1) @MultipartConfig     = beacause large objects are sent in multipart
*   2) POST method doPost() = use POST method when we upload file/pictures
*   
*   
*/


@MultipartConfig
@WebServlet({ "/BranchServlet1", "/branch1" })
public class BranchServlet1_1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BranchServlet1_1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String btn=request.getParameter("btn");
		String bid, bname, bcity;
		
		byte []pic;
		Part part= null;
		InputStream is = null;
		int len = 0;
		
		bid=request.getParameter("bid");
		BranchDao bdao=new BranchDao();
		Branch branch=null;
		int no=0;
		PrintWriter out = response.getWriter();
		switch(btn)
		{
		case "Select":
			bid= request.getParameter("bid");
			String str="";
			  try {
				 branch = bdao.read(bid);
				str= String.format("index-jstl-pic.jsp?bid=%s&bname=%s&bcity=%s",bid,branch.getBname(),branch.getBcity());	
			
			  } catch (ClassNotFoundException | SQLException e1) {
				e1.printStackTrace();
			}
			
			response.sendRedirect(str);
			break;
			
		case "Add":
			bname=request.getParameter("bname");
			bcity=request.getParameter("bcity");
			// also the pic
			                               // Part part=request.getPart("pic");
			                               // InputStream is = part.getInputStream();
			                               // int len = is.available();           
			                               // byte []pic = new byte[len];      
			                               // is.read(pic);                     
			part=request.getPart("pic");
			is = part.getInputStream();
			len = is.available();                     //    -----> this method returns number of bytes
			pic = new byte[len];
			is.read(pic);                             //     ----> is(Input Stream) is loaded into pic(array of byte[]) using read() method.
			
			branch=new Branch(bid, bname, bcity, pic);
			try {
				no=bdao.create(branch);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			response.sendRedirect("index-jstl-pic.jsp");
			break;
		case "Modify":
			bname=request.getParameter("bname");
			bcity=request.getParameter("bcity");
			
			part=request.getPart("pic");                        // picture
			is = part.getInputStream();
			len = is.available();
			pic = new byte[len];
			is.read(pic);
			
			branch=new Branch(bid, bname, bcity, pic);
			try {
				no=bdao.update(branch);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			response.sendRedirect("index-jstl-pic.jsp");
			break;
		case "Delete":
			try {
				no=bdao.delete(bid);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			response.sendRedirect("index-jstl-pic.jsp");
			break;
		}
	}

}
