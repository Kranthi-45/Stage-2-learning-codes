package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlet
 */
@WebServlet({ "/MyServlet", "/ms" })
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

		String country  = request.getParameter("countries");
		String gender  = request.getParameter("gender");
		
		// multiple check box can be selected, so we need array of strings.	
		String[] interests = request.getParameterValues("interests");
		PrintWriter out = response.getWriter();
		
        response.setContentType("text/html");    // for gettting print in new line
        out.print(country +"<br/>");
        out.print(gender+"<br/>");
        out.print("Interested hobbies "+Arrays.toString(interests));

//      out.println(country);
//      out.println(gender);                    //  println taking space not newline.

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
