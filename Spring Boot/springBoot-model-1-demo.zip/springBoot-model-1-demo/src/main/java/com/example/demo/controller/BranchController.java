package com.example.demo.controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.dao.BranchDao;
import com.example.demo.entity.Branch;

@Controller
public class BranchController {

//	@GetMapping("/branch")
//	public String home() 
//	{
//		return "branch";
//	}
//-----------------------------------------------------------------------------------------------------------------------------------------	
//	@GetMapping("/branch")
//	public String home(ModelMap modelMap) throws ClassNotFoundException, SQLException 
//	{
//		modelMap.addAttribute("username","Kranthi");          // To display this on webpage " write ${username} in jsp code "
//		modelMap.addAttribute("role","Admin");
//		
//		BranchDao bdao = new BranchDao();
//		List<Branch> branchList =  bdao.read();
//		modelMap.addAttribute("branches", branchList);        /* we are storing branchList in modelMap attribute
//		                                                       * To display all branches as table on webpage we need to use forEach loop in jsp file
//		                                                       * so " add <%taglib > directive " of jstl.jar in .jsp file to use <foreach> loop
//		                                                       */
//		
//		return "branch";
//	}
//-------------------------------------------------------------------------------------------------------------------------------------------------
	
	@GetMapping("/branch")
	public ModelAndView home() throws ClassNotFoundException, SQLException 
	{                                                                             // Using ModelAndView
		BranchDao bdao = new BranchDao();
		List<Branch> branchList =  bdao.read();
        ModelAndView mv = new ModelAndView();	
        mv.addObject("branches", branchList);
        mv.setViewName("branch");
        return mv;
	}	
}
