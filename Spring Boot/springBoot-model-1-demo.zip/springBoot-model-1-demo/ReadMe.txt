
# Suppose if you get error in "pom.xml" while creating springBoot proj
   RightClick Proj -> Maven -> Update Project.. -> Tick Force Snapshots -> Submit

#1) BranchController.java under Controller

#2) WEB-INF/jsp folder --    create branch.jsp file

#3) application.properties -- suffix / prefix
   
    Run the program once, 
    check  branch page is working or not -->  URL http://localhost:8080/branch
    this  Error in console              ---> Path with "WEB-INF" or "META-INF": [WEB-INF/jspbranch] then "Add tomcat"
   
    
#4) Add "Tomcat" dependency    if same error occurs

#5) Branch.java under entity  -- there is byte[] pic varible of Base64.. So we need Base 64 Dependency see below

#6) Add " Appache Commons Codec " Base64 dependency (1.15 version)

#7) BranchDoa.java under dao and basepackage  
      - Write the code in BranchDao.java (copy from " springBoot-branch-demo " proj)

#8) Add "my-sql-connector" & "jstl" jar (javax.servlet)  or dependencies  & update project once

#9) Write the code in branch.jsp (jumbotron,heading,buttons) and check once

#10) i) Using ModelMap - write the code in controller to display table of records passing to .jsp file
      
       - Create the table in jsp file to display on webpage by using <c:forEach> & also add " @taglib jstl " directive to use it 

     ii) Using ModelAndView - write the code in controller to display table of records passing to .jsp file

#11) see next project demo for add/modify/del methods (springBoot-model-branch-demo)
