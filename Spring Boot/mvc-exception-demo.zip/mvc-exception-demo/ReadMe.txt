Exception Handler in Spring MVC project
	what happens when an exception occurs
	what happens when we throw an exception
	
	the user does not like to see the java exception messages
	we can create a separate page that can be shown when an exception occurs

in this demo:
	we will write code that may cause exception
	we intentionally throw an exception
	we throw an user defined exception


	and then look into handling the exception using a page redirection with appropriate message

---------------------------------------------------------------------------------------------------------------------------------------
STEPS:

1) WEB-INF/jsp folder --> index.jsp file
2) Configure application.properties
3) MyController.java
4) add tomcat dependency in pom.xml
5) Run the program and test once

6) create login.jsp file now & copy bootstrap 3 lines
     -> after submitting the form ,redirect to login.jsp 
     
7) @ResonseBody is used in MyController class to print statements in browser else error will throw 

8) Run the program and give inputs for login & password
     -> (i/j)  if j=0 or "String" it will throws exception..in browser & in console also
   
   i) using inbuilt "error.jsp file: 
      -Catch that exception by creating "error.jsp" file -  if error is found autmaticaly the error.jsp file will get executed (all kind of errors handled)
  ii) using inbuilt exception :
         - specific errors like --Arithmetic , NumberFormat exceptions are handled
         - we should use @ExceptionHandler( ) annotations and create one .jsp file(for printing user exception) to handle those (arith,numberformat) exception
                   
9) Create "UserDefined exception" by creating DenominatorEightException.java class  
       -using normal method
       -using ModelAndView concept ---throw the exception and it will catch my ModelAndView exception class, it will print using, user defined exception class
                                      (DenominatorEightException.java)  on webpage ..use ${msg} in .jsp file to print the error