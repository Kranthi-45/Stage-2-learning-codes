package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.exception.DenominatorEightException;

@Controller
public class MyController {
	
	@GetMapping("/")
	public String home() {
		return "index";
	}
	
	@GetMapping("/showlogin")
	public String showLogin() {
		return "login";
	}
	
//	@PostMapping("/login")
//	@ResponseBody                                                      // below String return "Result" will be printed
//	public String validateLogin(String username, String password)      // username,password are variables of name="" attribute in <form> tag
//	{
//		System.out.println(username+" "+password);                     // to print in the console not in browser
//		int i=Integer.parseInt(username);
//		int j=Integer.parseInt(password);		
//		
//		return "Result is "+ (i/j);                                    // throws excpetion when j = 0 or "String" is given in login page(in web page)
//	}
	
	@PostMapping("/login")
	@ResponseBody                                                      // below String return "Result" will be printed
	public String validateLogin(String username, String password)      // username,password are variables of name="" attribute in <form> tag
	{
		System.out.println(username+" "+password);                     // to print in the console not in browser
		int i=Integer.parseInt(username);
		int j=Integer.parseInt(password);		
		if(j==8)
			{
				throw new DenominatorEightException("Denominator cannot be 8");
			
			}
		return "Result is "+ (i/j);                                    // throws excpetion when j = 0 or "String" is given in login page(in web page)
	}
	
	@ExceptionHandler(ArithmeticException.class)                       // for arithmetic errors this will executed, other than (Arithm errors) errors.jsp file executed
	public String arithmeticExceptionHandler(Exception ex) {
		return "dividebyzero";                                           
	}
	
	@ExceptionHandler(NumberFormatException.class)                    // other than "numbers or digits" are entered, this will execute & handle exception
	public String numberFormatExceptionHandler(Exception ex) {
		return "dividebyzero";                                           
	}
	
//	@ExceptionHandler(DenominatorEightException.class)                // handled when denomintor 8 is entered .. we are throwing this exception to handle
//	public String denom(DenominatorEightException ex) {               // -user defined exception (created our new excep DenominatorEightException.java class)
//		return "denom";                                           
//	}
	
	@ExceptionHandler(DenominatorEightException.class)               
	public ModelAndView denom(DenominatorEightException ex) {        
		ModelAndView mv = new ModelAndView();
		mv.addObject("msg",ex.getMessage());                           //  use ${msg} in .jsp to print throw(msg) error in web browser
		mv.setViewName("denom");
		return mv;                                           
	}
		
	
}
