package com.example.demo.exception;

public class DenominatorEightException extends RuntimeException
{
	// user defined exception - throw it (cotroller class) 
	public DenominatorEightException(String message)
	{
		super(message);
	}
}
