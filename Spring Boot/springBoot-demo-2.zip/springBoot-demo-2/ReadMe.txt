Hyperlink Redirecting to another page demo in Spring Boot Applocation :

1) create "WEB-INF/jsp" subfolder under webapp folder first

2) create "index.jsp" & "branch.jsp" under webapp/WEB-INF/jsp folder

3) Configure "application.properties" under resources folder

4) Create "BranchController" class under base package (that means i,e.. under main method package)

5) Run main method (springApplication.java) 
    type url in browser and check the output

 This demo using one controller, see next demo( springBoot-demo-2.1 )using two controller classes (BranchController and HomeController)