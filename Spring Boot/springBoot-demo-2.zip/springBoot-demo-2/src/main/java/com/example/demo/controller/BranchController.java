package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

// #4 Create "BranchController" class under base package (that means i,e.. under main method package)

@Controller
public class BranchController {

	@RequestMapping("/")
	public String home() 
	{
		return "index";
	}
	
	@RequestMapping("/branch")
	public String showBranchPage()
	{
		return "branch";
	}
}
