package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDemo2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDemo2Application.class, args);
	}

}

/* #5 At last, when you run this main method if you get error like : " file cannot be read from "
 *    then add " Apache tomcat " in target runtime or add dependency in pom.xml file
 *   
 *     O/P : http://localhost:8080/ (accessing home page) in browser
 *           http://localhost:8080/branch/ (accessing branch page) in browser
 *   
 */