package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

//#4 Create "BranchController" class under base package (that means i,e.. under main method package)

@Controller
@RequestMapping("/branch")
public class BranchController {

	@GetMapping("/")
	public String home() 
	{
		return "branch";
	}
		
}
