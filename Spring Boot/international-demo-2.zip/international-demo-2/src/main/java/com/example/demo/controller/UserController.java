package com.example.demo.controller;


import java.util.Locale;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.bean.User;

@Controller
public class UserController {

	@GetMapping("/")
	public String home()
	{
		return "index";
	}
	
	
//	@RequestMapping(value="/user", method = RequestMethod.GET)
	@GetMapping("/user")
	public ModelAndView user(Locale locale){
//		return new ModelAndView("userform","user",new User());
		ModelAndView mv=new ModelAndView();
		mv.setViewName("userform");
		mv.addObject("user", new User());
		return mv;
	}
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String  save(@ModelAttribute("user") User user) {
		System.out.println(user);
		return "success";
	}
}
