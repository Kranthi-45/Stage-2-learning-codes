package com.example.demo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.example.demo.entity.Branch;

// # 4 create dao and my-sql-connector jar --next application.properties
public class BranchDao {
	private Connection getConnection() throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.jdbc.Driver");
		return DriverManager.getConnection("jdbc:mysql://localhost:3306/kranthis","root","Ks_961796");
	}
	
	public int create(Branch branch) throws ClassNotFoundException, SQLException {
		//insert
		Connection con = getConnection();
		PreparedStatement st = con.prepareStatement("INSERT INTO branch1 VALUES(?,?,?,?)");
		st.setString(1, branch.getBid());
		st.setString(2, branch.getBname());
		st.setString(3, branch.getBcity());
		st.setBytes(4,branch.getPic());
		int no=st.executeUpdate();
		con.close();
		return no;
	}
	public List<Branch> read() throws ClassNotFoundException, SQLException {
		//select all
		Connection con = getConnection();
		PreparedStatement st = con.prepareStatement("SELECT * FROM branch1");
		ResultSet rs = st.executeQuery();
		//rs contains records. each record should be stored in a Branch object. All objects in a List<Branch>
		List<Branch> branchList=new ArrayList<>();
		while(rs.next())
		{
			Branch branch=new Branch(rs.getString(1), rs.getString(2), rs.getString(3),rs.getBytes(4));
			branchList.add(branch);
		}
		con.close();
		return branchList;
		
	}
	public Branch read(String bid) throws ClassNotFoundException, SQLException {
		//select by id
		Connection con = getConnection();
		PreparedStatement st = con.prepareStatement("SELECT * FROM branch1 WHERE bid=?");
		st.setString(1, bid);
		ResultSet rs = st.executeQuery();
		Branch branch=null;
		if(rs.next())
		{
			branch=new Branch(rs.getString(1), rs.getString(2), rs.getString(3),rs.getBytes(4));
		}
		con.close();
		return branch;
	}
	public int update(Branch branch) throws ClassNotFoundException, SQLException {
		//update
		Connection con = getConnection();
		PreparedStatement st = con.prepareStatement("UPDATE branch1 SET bname=?, bcity=?, pic=? WHERE bid=?");
		st.setString(1, branch.getBname());
		st.setString(2, branch.getBcity());
		st.setBytes(3,branch.getPic());
		st.setString(4, branch.getBid());
		int no=st.executeUpdate();
		con.close();
		return no;
	}
	public int delete(String bid) throws ClassNotFoundException, SQLException {
		//delete
		Connection con = getConnection();
		PreparedStatement st = con.prepareStatement("DELETE FROM branch1 WHERE bid=?");
		st.setString(1, bid);
		int no=st.executeUpdate();
		con.close();
		return no;
	}
	
}
