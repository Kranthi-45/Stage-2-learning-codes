package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

//#7 Create "BranchController" class under base package (that means i,e.. under main method package) next run main method

@Controller
@RequestMapping("/branch")
public class BranchController {


	@GetMapping("/")
	public String home() 
	{
		 // read all branches from db using dao here...store it in model and display jsp
		return "branch";
	}
	
	@PostMapping("/add")
	public String addBranch() {
		return "branch";
	}
}
