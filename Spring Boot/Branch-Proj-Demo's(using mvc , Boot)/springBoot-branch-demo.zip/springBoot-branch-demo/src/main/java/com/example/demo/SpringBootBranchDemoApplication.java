package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//#8 Run main method
@SpringBootApplication
public class SpringBootBranchDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootBranchDemoApplication.class, args);
	}

}

//Homepage URL -> http://localhost:8080/
