package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

// #6 Create "HomeController" another controller under base package (that means i,e.. under main method package)

@Controller
public class HomeController {

	@RequestMapping("/")
	public String home() 
	{
		return "index";
	}
}
