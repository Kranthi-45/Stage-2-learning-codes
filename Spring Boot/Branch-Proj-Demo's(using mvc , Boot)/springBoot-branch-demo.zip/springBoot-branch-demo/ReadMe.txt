1) Create index.jsp & branch.jsp under WEB-INF/jsp folder

2) Add .jstl jar or jstl dependency in pom.xml  (we used dependency) --> for displaying records on webpage using <c:forEach> & params
     	   
  ------>   <dependency>
	     		<groupId>javax.servlet</groupId>
	     		<artifactId>jstl</artifactId>
	     		<version>1.2</version>	
	        </dependency>
	        
3) Create Branch.java in entity package. (change the import to entity properly in index.jsp file)

4) Create BranchDao.java under dao package. (manage the imports correctly in dao class and jsp file)

5) Add my-sql-connector .jar or dependency(5.1.47 version)in pom.xml (we used dependency)  -- for above dao class
         
   ------>  <!-- https://mvnrepository.com/artifact/mysql/mysql-connector-java -->
			 <dependency>
    			 <groupId>mysql</groupId>
    			<artifactId>mysql-connector-java</artifactId>
    			<version>5.1.47</version>
			</dependency>
			
 6) change <usebean> tag in branch.jsp according to correct package .
 
 7) Add tomcat.jar in Targetted Runtime or add Dependency ( we used dependency)  --- for displaying html tabel on html page from database 
           
    ------>  <dependency>
                <groupId>org.apache.tomcat.embed</groupId>
                <artifactId>tomcat-embed-jasper</artifactId>
             </dependency>	     
 
 8) Configure " Application.properties "	
 
 9) Create Controller under base package
       BranchController --   for URL method mapping to access correct method from dao class according to button(url) we pressed and to display on webpage
       HomeController   --   for home page         
       
 10) Run Application.java class and type url in web browser check
           Homepage    -> http://localhost:8080/
           Branch page -> http://localhost:8080/branch/    
           
 11) Continuation of these project
 
     Next Project demo to submit the form when buttons( ADD/MODIFY/DELETE) is clicked        