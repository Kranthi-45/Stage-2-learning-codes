package com.example.demo.controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.dao.BranchDao;
import com.example.demo.entity.Branch;

@Controller
public class BranchController {

	@GetMapping("/branch")
	public ModelAndView home() throws ClassNotFoundException, SQLException 
	{                                                                             // Using ModelAndView
		BranchDao bdao = new BranchDao();
		List<Branch> branchList =  bdao.read();
        ModelAndView mv = new ModelAndView();	
        mv.addObject("branches", branchList);
        mv.setViewName("branch");
        return mv;
	}	
	
//	@PostMapping("/add")                          
//	public void addBranch(Branch branch) {      
//		System.out.println(branch);                                              //-----> #1 Print O/P in " Console "
//	}
	
	 
//	@PostMapping("/add")                          
//	@ResponseBody                                           // to inform that this method does not return URL, it returns value to be printed  in browser
//	public Branch addBranch(Branch branch) {
//		return branch;                                      //-----> #2 Print O/P in " Browser"   so,use @ResponseBody
//	}
//	
	
//	@PostMapping("/add")
//	@ResponseBody             	                      
//	public Branch addBranch(Branch branch) throws ClassNotFoundException, SQLException
//	{
//		BranchDao bdao = new BranchDao();
//		int status = bdao.create(branch);
//		if(status>0)
//			return branch;                                                      //-----> #2 Print O/P in Browser and "Store Data in Database"
//		return null;
//	}

	
	
//	@PostMapping("/add")                                                       // same as above #2 method but using ModelAndView concept
//	public ModelAndView addBranch(Branch branch) throws ClassNotFoundException, SQLException
//	{
//		BranchDao bdao = new BranchDao();
//		int status = bdao.create(branch);
//		return home();
//			                                                                 	
//	}
	
}
