package com.example.springstartSpringIo_Demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringStartSpringIoDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
