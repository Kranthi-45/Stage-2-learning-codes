package com.example.springstartSpringIo_Demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringStartSpringIoDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringStartSpringIoDemoApplication.class, args);
	}

}
