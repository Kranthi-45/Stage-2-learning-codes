 Spring Boot Application :

 see next project for full demo , this is only demonstration of spring boot project creation from web using "spring.io"

# we created  MVC project (spring-mvc-1 (project name)), so that java people work comfortably and independantly in java code
    
    	>	Now In " Spring Boot Application ", the same MVC project can be created little easily how?
   		>	if some one creates a project and configures all necessary steps and give the project to us, how easy it will be?
  
# There are Two process to create "Spring Starter Projects"   :
       
        1) Creating a project in (Spring initializer service) in below website  ( Useful for Eclpise IDES)
	          http://start.spring.io and download it
	    2) By Using "Spring Tool Suite":
	           File -> New -> Spring starter project      

# Now This demo using 1st method and next project by using 2nd one 
  STEPS:
     1) go to website http://start.spring.io provide the below information:
				group id
				artifact id
				java version    - 8
				maven / kradle  - Maven
				jar / war       - WAR
				Dependencies -> Add Dependencies  -	search and select ( Spring Web )

	    create project with name(ex: spring-start-Spring-Io_Demo ) downloaded to "downloads" folder ->
	    unzip to any location, -> import as "Existing maven project".
	    
	 2) Right Click Project -> properties -> Targeted Runtimes -> Select  " Apache Tomcat "    
	           
	 3) "starter" dependencies combines lot of dependencies inside.
	     In this Spring Boot Application:
	     				      
------------------------------------------------------------------------------------------------------------------------------------------	 
 # "Starter" dependencies combines lot of dependencies inside 
   In this Spring Boot Application:
	 	>   i dont need "web.xml"
	 	>	i dont need to configure dispatcher servlet here	(ready made)
		>	i dont need to create "spring-servlet.xml" also	(THEN HOW WILL I SPECIFY "prefix" and "suffix")
		     -we will configure this in "application.properties" file as below
	
				spring.mvc.view.prefix=/WEB-INF/jsp/
				spring.mvc.view.suffix=.jsp
	 
---------------------------------------------------------------------------SIR NOTES--------------------------------------------------------------------------------------------------------------------
                                     	 
                                     	 
  in a Spring boot application
	How we are going to store information across different views.
	What we do in the controller

	how we can manage the session information across pages?

in login page, i can enter username and password
	but in all other pages, my username is remembered by the application
	where is it stored?
		session
	until i logout, the username is remembered.

	the username is String. But user object????	can contain (username, role, firstName,........)

	so we can store an object or a List of objects in a session.

	before we learn session, lets learn model.

Bank demo:
	the jsp page, is displaying all the branches. Where is the list of branch?


different type of mappings

@RequestMapping
	can be used for any http method
		GET, POST, PUT, DELETE

@GetMapping
	means GET only
@PostMapping
@PutMapping
@DeleteMapping



@GetMapping("/select/{bid}")					bid is a pathvariable here
                                     	 