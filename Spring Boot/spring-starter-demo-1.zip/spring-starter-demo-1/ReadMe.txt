 Spring Boot Application :

# we created  MVC previous project (spring-mvc-1 (project name)), so that java people work comfortably and independantly in java code
    
    	>	Now In " Spring Boot Application ", the same MVC project can be created little easily how?
   		>	if some one creates a project and configures all necessary steps and give the project to us, how easy it will be?
 
# "Starter" dependencies combines lot of dependencies inside
   In this Spring Boot Application:
	 	>   i dont need "web.xml"
	 	>	i dont need to configure dispatcher servlet here	(ready made)
		>	i dont need to create "spring-servlet.xml" also	(THEN HOW WILL I SPECIFY "prefix" and "suffix")
		     -we will configure this in "application.properties" file as below
	
				spring.mvc.view.prefix=/WEB-INF/jsp/
				spring.mvc.view.suffix=.jsp
 
# There are Two process to create "Spring Starter Projects"   :
       
        1) Creating a project in (Spring initializer service) in below website  ( Useful for Eclpise IDES)
	          http://start.spring.io and download it
	    2) By Using "Spring Tool Suite":
	           File -> New -> Spring starter project      

# Now This demo using 1st method and next project by using 2nd one 
  STEPS:(2ND method this proj)
     1) --> go to website http://start.spring.io provide the below information:
				group id
				artifact id
				java version    - 8
				maven / kradle  - Maven
				jar / war       - WAR
				Dependencies -> Add Dependencies  -	search and select ( Spring Web )

	        create project downloaded to "downloads" folder. unzip to any location, import as "Existing maven project".
	        
	                                 (or)
	                                 
	    --> By Using "Spring Tool Suite":    File -> New -> Spring starter project            
	                                 
	 2) Right Click Project -> properties -> Targeted Runtimes -> Select  " Apache Tomcat .jar " or add dependency in pom.xml file    
	           
	 3) Configure "application.properties" file  as below:
	   
			spring.mvc.view.prefix=/WEB-INF/jsp/
			spring.mvc.view.suffix=.jsp

     4) As required, we have created "WEB-INF/jsp" folder under "webapp" folder created " index.jsp " file also.
     
     5) Create classes " MyController.java" --Normally we specify the "base package" in the component scan @Component() in controller class.
          
          - But in spring boot, "convention over configuration" ?
          - create your controller classes under the base package. (Package that contains -- main method (App.java)) --> " SpringDemo1Application.java "
	      
	       # "Convention" is we can create sub packages (but not change entire package).
	  
	 6) Open the application.java (contains main method) run as "spring boot app"  
	   
	    For OUTPUT check : check the port number and context  in console
	       #  Tomcat started on port(s): 8080 (http) with context path ''
              
              URL is : http://localhost:8080/   (for above empty context path this is url) type in webpage see output
	        
	     
	     
	     
	     
	     
	  