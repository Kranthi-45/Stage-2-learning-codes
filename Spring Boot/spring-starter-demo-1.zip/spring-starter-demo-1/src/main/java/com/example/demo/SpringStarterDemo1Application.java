package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

// #5 Run this main method finally

@SpringBootApplication
public class SpringStarterDemo1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringStarterDemo1Application.class, args);
	}

}
