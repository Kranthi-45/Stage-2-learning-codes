package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

// #3 " MyController.java " finally under base package(under main method package only)

@Controller
public class MyController {

	
	@RequestMapping("/")
	public String home() {
		return "index";
	}
}
