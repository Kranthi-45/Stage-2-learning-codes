package com.cts.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/* 1) "deployment descriptor stub" -> while creating project click on Generate web.xml or right click on proj then add deployment descriptor stub
			 #	because this will create folders like --> WEB-INF folder for using in maven proj or else
             #  In Maven Project it will not create WEB-INF folder, have create manually
   
   2) Covert Project --> Maven Project  (rightclick proj --> configure --> covert to maven project)  
   3) In POM.xml, we need to add dependency for spring mvc.
   4) Configure "web.xml", so that any request is taken by Dispatcher servlet  (add "<Servlet> and <Servlet mapping> /url" dependency in "web.xml")
   5) Configure " -servlet.xml",
             # In "spring" , the configuration file can be created as " bean.xml or ApplicationContext.xml "
             # Same way In web.xml file, the dispatcher servlet name is "spring" means then bean.xml should be as "spring-servlet.xml"( " -servlet.xml"is common)
                   -create "spring-servlet.xml" in lib folder
   6)spring-servlet.xml 
             # Configure the prefix : /WEB-INF/jsp      
                             suffix : .jsp                ex: if say "index" in controller, prefixed & suffixed as " /WEB-INF/jsp/index.jsp "
    
   7) Create "jsp" Sub folder under "WEB-INF folder"
   8) Create " index.jsp " file in jsp sub folder or Add jsp pages to this folder.
   9) Create a class "MyController" under src/main package specified in the component scan. (this MyController.java class is created at last)
               
*/  
@Controller
public class MyController {

	@RequestMapping("/")                                        // localhost:8080/spring-mvc-1/ (type url in webpage to access this method)
	public String home() {
		return "index";                                         // index is traslated using prefix and suffix as " /WEB-INF/jsp/index.jsp "
	}
	
	@RequestMapping("/contact")                                 // localhost:8080/spring-mvc-1/contact (another diff url for different methods)
	public String contactUs() {
		return "contactus";
	}
}

/*  For Every @RequestMapping() for each method in Controller.java there is separate JSP file  is created for each method in WEB-INF/jsp folder
 *  Separate URL's for Separate jsp files to access
 *  
 */



