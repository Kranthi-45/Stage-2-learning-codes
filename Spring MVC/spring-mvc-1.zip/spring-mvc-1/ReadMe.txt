 
 # 1 demo for " Spring MVC Configuration "
    remaining demos in " Spring boot MVC Convention" (over configuration) 
 
 
 # we have learned servlets and jsp to create a dynamic web project that can submit a form to a servlet
    1) Form Submitted using HTML and JSP file as well
    2) JSP allows us to write java code in Html code (using scriplet) that is advantage  
    3) For more easy to read we used custom tags( jstl .jar) to decrease more java code in html 
       i,e JSTL core
    4) servlet, jsp are web components developed in java language that runs in server   

 # we are moving to next level of learning web application.
    MVC projects:
		> Model  
		        - entity,dao or model itself
		> View    
		        - input/output codes ,contains all JSP, html files, servlets(jsp, html, servlet (sometimes, servlet produces output))
		> Controller  
		        - in java, servlet is the controller	
				  we create an environment where a POJO class can be a controller (servlet will be underlying)
				  so far we created a servlet as a class that extends HttpServlet (so it is not POJO)
				  so we will learn to create POJO class in the place of controller
		         
 that is the need for learning MVC now and we can call above project as "MVC Project".
 
 # Spring MVC Project :
 
  what exactly we are going to do in spring mvc ?

	1) we create a POJO class for controller --> multiple methods. each method for one purpose. each method have an URL

	   what we did last session till before mvc projects ?  ADD	UPDATE	DELETE		(buttons)

	   For all three buttons, the form submitted to 1 servlet. in that servlet, we used switch case that is not nice. Instead, why not we have 3 different methods???????????
	   
	2) A Controller is a POJO class, that is going to define separate methods for each purpose. each method accessed using different url

	      How is it possible?
	      suppose, the servlet is accessed by a URL
						http://localhost:8080/projectname/add
						http://localhost:8080/projectname/modify
						http://localhost:8080/projectname/delete   
		  all these urls are received by a Servlet in the background, then that servlet understand the url as 
		 	       add
			 	   update
			 	   delete
	      and decide which method to be executed then THAT SERVLET IS CALLED AS "Dispatcher Servlet"	
	   
	3)  This "Dispatcher Servlet" is not created by me. It is already there in Spring MVC framework because of this dispatcher servlet, I AM NOT GOING TO CREATE ANY SERVLETS ANYMORE.
	     I am going to create POJO classes that acts as a controller
    
    4)  So in MVC project, an URL is not meant for a page. An URL is meant for a method in the controller class. 
    
   	   			ex: http://localhost:8080/projectname/add
	                here, "add" is the url that does not mean a page. it means a url mapped in a method in the controller class
	                
 